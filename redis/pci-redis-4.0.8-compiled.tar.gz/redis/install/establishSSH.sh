#!/bin/bash
#指定需要建立信任关系的用户名
USER_UID=$1
#系统用户home目录
USER_DIR=$3
#用户对应的密码，此脚本要求每台服务器的相同用户的密码必须一致
USER_PW=$2
#定义function establishSSH
establishSSH()
{
cat > establishSSH.exp << EOF
#!/usr/bin/expect
spawn ssh-copy-id -i $USER_DIR/.ssh/id_rsa.pub $SSH_IP
expect {
 "*yes/no*" { send "yes\r"; exp_continue }
 "*assword*" { send "$USER_PW\r"; }
}
expect eof
EOF
chmod 755 establishSSH.exp
./establishSSH.exp > /dev/null
/bin/rm -rf establishSSH.exp
}

if [ -f servers.txt ]
then
 :
else
 echo
 echo "----------------- please touch File:servers.txt ---------------"
 echo "################# servers.txt For Example       ###############"
 echo "bigdata03" 
 exit 0
fi

if [ `rpm -qa | grep expect` ]
then
 echo "os has installed expect"
else
 yum -y install expect > /dev/null
fi

if [ -f $USER_DIR/.ssh/id_rsa.pub ]
then
 :
else
 echo "---------------------- please first generate ssh 证书 -----------"
 echo "产生证书命令: ssh-keygen -t rsa"
 exit 0
fi

for SSH_IP in `cat servers.txt`
do
 establishSSH
 if [ $? -eq 0 ]
 then
  echo "------------------------ $SSH_IP is ok -----------------------"
 else
  echo "------------------------ $SSH_IP is failed -------------------"
 fi
done
