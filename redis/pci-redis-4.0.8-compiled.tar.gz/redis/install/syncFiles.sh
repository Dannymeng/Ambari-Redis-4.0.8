#!/bin/bash
function printUsage {
  echo "复制目录或单个文件到所有服务器对应的目录下"
  echo "Usage: copyFiles COMMAND [COMMAND_ARGS]"
  echo
  echo "COMMAND is one of:"
  echo -e " dir <PATH>\t 复制一个目录到所有服务器节点对应的目录下"
  echo -e " file <PATH> [解压目录]\t 复制单个文件到所有服务器节点对应的目录下,针对压缩文件，指定解压的目录[需要提前创建好]"
  echo
  echo "Commands print help when invoked without parameters."
}
##需要排除本机IP
function copyDir {
  if [[ $# -ne 1 ]]; then
    echo "Usage: copyFiles dir <path>" >&2
    exit 1
  fi

  SERVERS=`cat servers.txt | grep -v '^#' | awk '{print $2}'`

  DIR=`readlink -f "$1"`
  DIR=`echo ${DIR}|sed 's@/$@@'`
  DEST=`dirname ${DIR}`

  SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=5"

  echo "RSYNC'ing ${DIR} to servers..."
  localHostname=`hostname`
  for server in ${SERVERS}; do
      echo ${server}
      if [[ $server == $localHostname ]];
      then
        echo "跳过本地"
        continue
      fi
      rsync -e "ssh ${SSH_OPTS}" -az ${DIR} ${server}:${DEST} & sleep 0.05
  done
  wait
}

function copyFile {
  if [[ $# -lt 1 ]]; then
    echo "Usage: copyFiles file <path>" >&2
    exit 1
  fi

  SERVERS=`cat servers.txt | grep -v '^#' | awk '{print $2}'`

  DIR=`readlink -f "$1"`
  DIR=`echo ${DIR}|sed 's@/$@@'`
  DEST=`dirname ${DIR}`
  FILENAME=`basename ${1}`
  echo "SCP'ing ${1} to servers..."
  localHostname=`hostname`
  for server in ${SERVERS}; do
      if [[ $server == $localHostname ]];
      then
        continue
      else
        echo "复制文件到${server}"
      fi
      
      sshcmd $server "if [[ -d ${DEST} ]]; then :; else mkdir ${DEST}; fi" 
      scp "$1" ${server}:${DEST}
      
      if [[ $# == 2 ]]; 
      then
        echo "开始解压${server}:${DEST}${FILENAME}"
        sshcmd $server "if [[ -d $2 ]]; then :; else mkdir $2; fi"
        sshcmd $server "tar -pzxf $1 -C $2"
        echo "解压${server}:${DEST}${FILENAME}完成"
        
      fi
  done
}

function sshcmd {
  echo "    执行命令 ssh $1 $2"
  ssh $1 $2
}


function main {
  if [[ $# -lt 1 ]]; then
    printUsage
    exit 1
  fi
  COMMAND=$1
  shift
  
  case ${COMMAND} in
  "dir")
    copyDir "$@"
  ;;
  "file")
    copyFile "$@"
  ;;
  *)
    echo "Unsupported command ${COMMAND}" >&2
    echo 
    printUsage
    exit 1
  ;;
  esac
}
main "$@"
